class Explicit{
    public static void main(String[] args){
        double d = 234.04;
        long l = (long)d;   //explicit type casting
        int i = (int)l;     //explicit type casting
        System.out.println("double value " + d);
        System.out.println("long value " + l);
        System.out.println("int value " + i);
    }
}